import sys
import argparse

# Function to print the grid in a nice format
def print_grid(grid):
    print("+---+---+---+---+---+---+---+---+---+")
    for i in range(9):
        row = ""
        for j in range(9):
            val = grid[i][j] if grid[i][j] != 0 else " "
            row += f" {val} "
            if (j + 1) % 3 == 0 and j < 8:
                row += "|"
        print("|" + row + "|")
        if (i + 1) % 3 == 0 and i < 8:
            print("+---+---+---+---+---+---+---+---+---+")

# Function to read the puzzle from file
def read_puzzle(file_path):
    grid = []
    try:
        with open(file_path, 'r') as f:
            for line in f:
                # Remove whitespace and split into digits
                digits = [int(d) for d in line.replace(" ", "").strip() if d.isdigit()]
                if len(digits) != 9:
                    raise ValueError("Each line must have exactly 9 digits.")
                grid.append(digits)
        if len(grid) != 9:
            raise ValueError("Puzzle must have exactly 9 lines.")
        return grid
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        sys.exit(1)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)

# Function to write the solved puzzle to file
def write_puzzle(grid, file_path):
    with open(file_path, 'w') as f:
        for row in grid:
            f.write(" ".join(str(cell) for cell in row) + "\n")

# Function to initialize possible values for each cell
def init_possibilities(grid):
    possibilities = [[set(range(1, 10)) for _ in range(9)] for _ in range(9)]
    for i in range(9):
        for j in range(9):
            if grid[i][j] != 0:
                possibilities[i][j] = set()
            else:
                # Eliminate based on row, column, and box
                for k in range(9):
                    if grid[i][k] != 0:
                        possibilities[i][j].discard(grid[i][k])
                    if grid[k][j] != 0:
                        possibilities[i][j].discard(grid[k][j])
                box_row, box_col = (i // 3) * 3, (j // 3) * 3
                for r in range(box_row, box_row + 3):
                    for c in range(box_col, box_col + 3):
                        if grid[r][c] != 0:
                            possibilities[i][j].discard(grid[r][c])
    return possibilities

# Function to check if the puzzle is solved
def is_solved(grid):
    for row in grid:
        if 0 in row:
            return False
    return True

# Function to apply Naked Single
def naked_single(grid, possibilities):
    changed = False
    for i in range(9):
        for j in range(9):
            if grid[i][j] == 0 and len(possibilities[i][j]) == 1:
                val = list(possibilities[i][j])[0]
                grid[i][j] = val
                possibilities[i][j] = set()
                print(f"Naked Single: Row {i+1}, Column {j+1} can only be {val}")
                changed = True
    return changed

# Function to apply Hidden Single
def hidden_single(grid, possibilities):
    changed = False
    # Check rows
    for i in range(9):
        for num in range(1, 10):
            possible_cells = []
            for j in range(9):
                if grid[i][j] == 0 and num in possibilities[i][j]:
                    possible_cells.append(j)
            if len(possible_cells) == 1:
                j = possible_cells[0]
                grid[i][j] = num
                possibilities[i][j] = set()
                print(f"Hidden Single: In Row {i+1}, {num} can only go in Column {j+1}")
                changed = True
    # Check columns
    for j in range(9):
        for num in range(1, 10):
            possible_cells = []
            for i in range(9):
                if grid[i][j] == 0 and num in possibilities[i][j]:
                    possible_cells.append(i)
            if len(possible_cells) == 1:
                i = possible_cells[0]
                grid[i][j] = num
                possibilities[i][j] = set()
                print(f"Hidden Single: In Column {j+1}, {num} can only go in Row {i+1}")
                changed = True
    # Check boxes
    for box in range(9):
        box_row, box_col = (box // 3) * 3, (box % 3) * 3
        for num in range(1, 10):
            possible_cells = []
            for r in range(box_row, box_row + 3):
                for c in range(box_col, box_col + 3):
                    if grid[r][c] == 0 and num in possibilities[r][c]:
                        possible_cells.append((r, c))
            if len(possible_cells) == 1:
                r, c = possible_cells[0]
                grid[r][c] = num
                possibilities[r][c] = set()
                print(f"Hidden Single: In Box {box+1}, {num} can only go in Row {r+1}, Column {c+1}")
                changed = True
    return changed

# Function to apply Naked Pair
def naked_pair(grid, possibilities):
    changed = False
    # Helper to check a unit (row, col, or box)
    def check_unit(cells):
        nonlocal changed
        for i in range(len(cells)):
            for j in range(i + 1, len(cells)):
                r1, c1 = cells[i]
                r2, c2 = cells[j]
                if (grid[r1][c1] == 0 and grid[r2][c2] == 0 and
                    possibilities[r1][c1] == possibilities[r2][c2] and len(possibilities[r1][c1]) == 2):
                    pair_vals = possibilities[r1][c1]
                    print(f"Naked Pair: Cells ({r1+1},{c1+1}) and ({r2+1},{c2+1}) share {pair_vals}. Eliminating from other cells in the unit.")
                    for r, c in cells:
                        if (r, c) != (r1, c1) and (r, c) != (r2, c2) and grid[r][c] == 0:
                            before = len(possibilities[r][c])
                            possibilities[r][c] -= pair_vals
                            if len(possibilities[r][c]) < before:
                                changed = True
    # Check rows
    for i in range(9):
        cells = [(i, j) for j in range(9)]
        check_unit(cells)
    # Check columns
    for j in range(9):
        cells = [(i, j) for i in range(9)]
        check_unit(cells)
    # Check boxes
    for box in range(9):
        box_row, box_col = (box // 3) * 3, (box % 3) * 3
        cells = [(r, c) for r in range(box_row, box_row + 3) for c in range(box_col, box_col + 3)]
        check_unit(cells)
    return changed

# Main solving function
def solve_sudoku(grid):
    possibilities = init_possibilities(grid)
    steps = 0
    while not is_solved(grid) and steps < 100:  # Prevent infinite loops
        changed = False
        changed |= naked_single(grid, possibilities)
        changed |= hidden_single(grid, possibilities)
        changed |= naked_pair(grid, possibilities)
        if changed:
            print("Updated grid:")
            print_grid(grid)
            print()
        else:
            print("No more logical steps possible. Puzzle may require advanced techniques or be invalid.")
            break
        steps += 1
    return is_solved(grid)

# Main function
def main():
    parser = argparse.ArgumentParser(description="Solve a Sudoku puzzle.")
    parser.add_argument("input_file", help="Path to the input puzzle file")
    parser.add_argument("-o", "--output_file", required=True, help="Path to the output solved puzzle file")
    args = parser.parse_args()

    print(f"Solving puzzle from {args.input_file}")
    grid = read_puzzle(args.input_file)
    print("Initial grid:")
    print_grid(grid)
    print()

    if solve_sudoku(grid):
        print("Puzzle solved!")
        write_puzzle(grid, args.output_file)
        print(f"Solution written to {args.output_file}")
    else:
        print("Failed to solve the puzzle.")

if __name__ == "__main__":
    main()
